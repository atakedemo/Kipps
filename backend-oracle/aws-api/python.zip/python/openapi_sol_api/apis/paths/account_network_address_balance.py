from openapi_sol_api.paths.account_network_address_balance.get import ApiForget


class AccountNetworkAddressBalance(
    ApiForget,
):
    pass
