from openapi_sol_api.paths.account_network_address_tokens.get import ApiForget


class AccountNetworkAddressTokens(
    ApiForget,
):
    pass
