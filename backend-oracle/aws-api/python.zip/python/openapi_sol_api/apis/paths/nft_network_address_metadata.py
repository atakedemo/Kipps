from openapi_sol_api.paths.nft_network_address_metadata.get import ApiForget


class NftNetworkAddressMetadata(
    ApiForget,
):
    pass
