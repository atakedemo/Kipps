from openapi_sol_api.paths.token_network_address_price.get import ApiForget


class TokenNetworkAddressPrice(
    ApiForget,
):
    pass
