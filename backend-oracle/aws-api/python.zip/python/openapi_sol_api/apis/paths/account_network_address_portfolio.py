from openapi_sol_api.paths.account_network_address_portfolio.get import ApiForget


class AccountNetworkAddressPortfolio(
    ApiForget,
):
    pass
