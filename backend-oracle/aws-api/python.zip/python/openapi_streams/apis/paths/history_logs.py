from openapi_streams.paths.history_logs.get import ApiForget


class HistoryLogs(
    ApiForget,
):
    pass
