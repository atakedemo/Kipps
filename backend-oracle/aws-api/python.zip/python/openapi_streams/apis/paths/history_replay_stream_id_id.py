from openapi_streams.paths.history_replay_stream_id_id.post import ApiForpost


class HistoryReplayStreamIdId(
    ApiForpost,
):
    pass
