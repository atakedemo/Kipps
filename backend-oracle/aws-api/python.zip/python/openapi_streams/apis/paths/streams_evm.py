from openapi_streams.paths.streams_evm.get import ApiForget
from openapi_streams.paths.streams_evm.put import ApiForput


class StreamsEvm(
    ApiForget,
    ApiForput,
):
    pass
