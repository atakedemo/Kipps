from openapi_streams.paths.streams_aptos.get import ApiForget
from openapi_streams.paths.streams_aptos.put import ApiForput


class StreamsAptos(
    ApiForget,
    ApiForput,
):
    pass
