from openapi_streams.paths.history.get import ApiForget


class History(
    ApiForget,
):
    pass
