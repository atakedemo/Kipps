from openapi_streams.paths.settings.get import ApiForget
from openapi_streams.paths.settings.post import ApiForpost


class Settings(
    ApiForget,
    ApiForpost,
):
    pass
