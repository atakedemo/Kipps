from openapi_streams.paths.streams_aptos_id_status.post import ApiForpost


class StreamsAptosIdStatus(
    ApiForpost,
):
    pass
