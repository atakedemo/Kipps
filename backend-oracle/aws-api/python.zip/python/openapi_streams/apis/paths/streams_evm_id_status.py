from openapi_streams.paths.streams_evm_id_status.post import ApiForpost


class StreamsEvmIdStatus(
    ApiForpost,
):
    pass
