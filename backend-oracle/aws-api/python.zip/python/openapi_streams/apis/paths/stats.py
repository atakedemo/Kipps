from openapi_streams.paths.stats.get import ApiForget


class Stats(
    ApiForget,
):
    pass
