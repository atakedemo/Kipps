from openapi_streams.paths.stats_stream_id.get import ApiForget


class StatsStreamId(
    ApiForget,
):
    pass
