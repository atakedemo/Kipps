from openapi_auth.paths.bind_request_verify.post import ApiForpost


class BindRequestVerify(
    ApiForpost,
):
    pass
