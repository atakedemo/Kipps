from openapi_auth.paths.profile_profile_id_addresses.get import ApiForget


class ProfileProfileIdAddresses(
    ApiForget,
):
    pass
