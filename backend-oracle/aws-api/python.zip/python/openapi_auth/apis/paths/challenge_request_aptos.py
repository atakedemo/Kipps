from openapi_auth.paths.challenge_request_aptos.post import ApiForpost


class ChallengeRequestAptos(
    ApiForpost,
):
    pass
