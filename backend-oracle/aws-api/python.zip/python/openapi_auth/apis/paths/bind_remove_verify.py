from openapi_auth.paths.bind_remove_verify.post import ApiForpost


class BindRemoveVerify(
    ApiForpost,
):
    pass
