from openapi_auth.paths.challenge_request_solana.post import ApiForpost


class ChallengeRequestSolana(
    ApiForpost,
):
    pass
