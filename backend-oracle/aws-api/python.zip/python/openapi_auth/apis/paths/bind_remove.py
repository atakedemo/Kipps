from openapi_auth.paths.bind_remove.post import ApiForpost


class BindRemove(
    ApiForpost,
):
    pass
