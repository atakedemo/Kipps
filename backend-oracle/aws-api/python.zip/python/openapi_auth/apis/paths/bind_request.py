from openapi_auth.paths.bind_request.post import ApiForpost


class BindRequest(
    ApiForpost,
):
    pass
