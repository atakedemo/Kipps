from openapi_auth.paths.challenge_request_evm.post import ApiForpost


class ChallengeRequestEvm(
    ApiForpost,
):
    pass
