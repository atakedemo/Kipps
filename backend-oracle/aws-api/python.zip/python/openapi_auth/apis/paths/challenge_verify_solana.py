from openapi_auth.paths.challenge_verify_solana.post import ApiForpost


class ChallengeVerifySolana(
    ApiForpost,
):
    pass
