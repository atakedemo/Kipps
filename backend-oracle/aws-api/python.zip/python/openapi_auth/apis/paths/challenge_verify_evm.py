from openapi_auth.paths.challenge_verify_evm.post import ApiForpost


class ChallengeVerifyEvm(
    ApiForpost,
):
    pass
