from openapi_auth.paths.challenge_verify_aptos.post import ApiForpost


class ChallengeVerifyAptos(
    ApiForpost,
):
    pass
