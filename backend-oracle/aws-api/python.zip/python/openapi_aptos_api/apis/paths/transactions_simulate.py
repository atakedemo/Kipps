from openapi_aptos_api.paths.transactions_simulate.post import ApiForpost


class TransactionsSimulate(
    ApiForpost,
):
    pass
