from openapi_aptos_api.paths.coins_owners_coin_type_hash_top_holders.get import ApiForget


class CoinsOwnersCoinTypeHashTopHolders(
    ApiForget,
):
    pass
