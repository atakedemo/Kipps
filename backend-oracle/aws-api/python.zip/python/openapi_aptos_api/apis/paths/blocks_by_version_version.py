from openapi_aptos_api.paths.blocks_by_version_version.get import ApiForget


class BlocksByVersionVersion(
    ApiForget,
):
    pass
