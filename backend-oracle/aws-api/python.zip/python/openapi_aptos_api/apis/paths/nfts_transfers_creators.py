from openapi_aptos_api.paths.nfts_transfers_creators.get import ApiForget


class NftsTransfersCreators(
    ApiForget,
):
    pass
