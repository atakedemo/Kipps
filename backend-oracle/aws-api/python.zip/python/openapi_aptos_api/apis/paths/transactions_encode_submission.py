from openapi_aptos_api.paths.transactions_encode_submission.post import ApiForpost


class TransactionsEncodeSubmission(
    ApiForpost,
):
    pass
