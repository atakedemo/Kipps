from openapi_aptos_api.paths.nfts_transfers_collections_collection_data_id_hash.get import ApiForget


class NftsTransfersCollectionsCollectionDataIdHash(
    ApiForget,
):
    pass
