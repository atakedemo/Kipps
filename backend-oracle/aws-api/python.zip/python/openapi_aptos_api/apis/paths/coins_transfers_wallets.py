from openapi_aptos_api.paths.coins_transfers_wallets.get import ApiForget


class CoinsTransfersWallets(
    ApiForget,
):
    pass
