from openapi_aptos_api.paths.accounts_address_events_creation_number.get import ApiForget


class AccountsAddressEventsCreationNumber(
    ApiForget,
):
    pass
