from openapi_aptos_api.paths.nfts_transfers.get import ApiForget


class NftsTransfers(
    ApiForget,
):
    pass
