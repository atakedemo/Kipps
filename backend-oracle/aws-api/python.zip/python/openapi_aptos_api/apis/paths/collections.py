from openapi_aptos_api.paths.collections.get import ApiForget


class Collections(
    ApiForget,
):
    pass
