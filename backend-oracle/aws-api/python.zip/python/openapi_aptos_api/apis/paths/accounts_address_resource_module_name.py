from openapi_aptos_api.paths.accounts_address_resource_module_name.get import ApiForget


class AccountsAddressResourceModuleName(
    ApiForget,
):
    pass
