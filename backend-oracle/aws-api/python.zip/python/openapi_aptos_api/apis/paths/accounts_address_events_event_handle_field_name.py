from openapi_aptos_api.paths.accounts_address_events_event_handle_field_name.get import ApiForget


class AccountsAddressEventsEventHandleFieldName(
    ApiForget,
):
    pass
