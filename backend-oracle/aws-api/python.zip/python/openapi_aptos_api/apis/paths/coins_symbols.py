from openapi_aptos_api.paths.coins_symbols.get import ApiForget


class CoinsSymbols(
    ApiForget,
):
    pass
