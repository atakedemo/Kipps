from openapi_aptos_api.paths.accounts_address_modules.get import ApiForget


class AccountsAddressModules(
    ApiForget,
):
    pass
