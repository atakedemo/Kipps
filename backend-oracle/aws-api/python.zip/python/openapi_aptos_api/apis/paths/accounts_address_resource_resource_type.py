from openapi_aptos_api.paths.accounts_address_resource_resource_type.get import ApiForget


class AccountsAddressResourceResourceType(
    ApiForget,
):
    pass
