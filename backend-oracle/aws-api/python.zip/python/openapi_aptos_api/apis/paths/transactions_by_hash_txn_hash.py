from openapi_aptos_api.paths.transactions_by_hash_txn_hash.get import ApiForget


class TransactionsByHashTxnHash(
    ApiForget,
):
    pass
