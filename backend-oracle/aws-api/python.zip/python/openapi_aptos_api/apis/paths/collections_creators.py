from openapi_aptos_api.paths.collections_creators.get import ApiForget


class CollectionsCreators(
    ApiForget,
):
    pass
