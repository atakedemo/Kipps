from openapi_aptos_api.paths.wallets_coins_history.get import ApiForget


class WalletsCoinsHistory(
    ApiForget,
):
    pass
