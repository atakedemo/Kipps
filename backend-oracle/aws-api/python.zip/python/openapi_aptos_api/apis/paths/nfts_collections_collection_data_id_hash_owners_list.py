from openapi_aptos_api.paths.nfts_collections_collection_data_id_hash_owners_list.get import ApiForget


class NftsCollectionsCollectionDataIdHashOwnersList(
    ApiForget,
):
    pass
