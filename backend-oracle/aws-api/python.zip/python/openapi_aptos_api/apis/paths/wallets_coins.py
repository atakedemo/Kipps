from openapi_aptos_api.paths.wallets_coins.get import ApiForget


class WalletsCoins(
    ApiForget,
):
    pass
