from openapi_aptos_api.paths.nfts.get import ApiForget


class Nfts(
    ApiForget,
):
    pass
