from openapi_aptos_api.paths.nfts_owners.get import ApiForget


class NftsOwners(
    ApiForget,
):
    pass
