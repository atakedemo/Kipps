from openapi_aptos_api.paths.wallets_nfts_transfers.get import ApiForget


class WalletsNftsTransfers(
    ApiForget,
):
    pass
