from openapi_aptos_api.paths.coins_names.get import ApiForget


class CoinsNames(
    ApiForget,
):
    pass
