from openapi_aptos_api.paths.coins_creators.get import ApiForget


class CoinsCreators(
    ApiForget,
):
    pass
