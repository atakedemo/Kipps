from openapi_aptos_api.paths.nfts_creators.get import ApiForget


class NftsCreators(
    ApiForget,
):
    pass
