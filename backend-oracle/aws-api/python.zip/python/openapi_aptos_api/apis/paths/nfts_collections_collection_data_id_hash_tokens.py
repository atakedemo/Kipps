from openapi_aptos_api.paths.nfts_collections_collection_data_id_hash_tokens.get import ApiForget


class NftsCollectionsCollectionDataIdHashTokens(
    ApiForget,
):
    pass
