from openapi_aptos_api.paths.accounts_address.get import ApiForget


class AccountsAddress(
    ApiForget,
):
    pass
