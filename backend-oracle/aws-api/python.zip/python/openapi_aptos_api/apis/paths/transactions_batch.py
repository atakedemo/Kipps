from openapi_aptos_api.paths.transactions_batch.post import ApiForpost


class TransactionsBatch(
    ApiForpost,
):
    pass
