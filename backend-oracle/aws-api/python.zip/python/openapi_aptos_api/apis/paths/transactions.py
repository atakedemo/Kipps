from openapi_aptos_api.paths.transactions.get import ApiForget
from openapi_aptos_api.paths.transactions.post import ApiForpost


class Transactions(
    ApiForget,
    ApiForpost,
):
    pass
