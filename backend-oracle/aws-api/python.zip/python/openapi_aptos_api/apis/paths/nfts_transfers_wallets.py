from openapi_aptos_api.paths.nfts_transfers_wallets.get import ApiForget


class NftsTransfersWallets(
    ApiForget,
):
    pass
