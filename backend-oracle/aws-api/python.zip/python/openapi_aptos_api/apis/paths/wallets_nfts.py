from openapi_aptos_api.paths.wallets_nfts.get import ApiForget


class WalletsNfts(
    ApiForget,
):
    pass
