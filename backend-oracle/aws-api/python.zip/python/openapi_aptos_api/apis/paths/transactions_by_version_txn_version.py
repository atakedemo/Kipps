from openapi_aptos_api.paths.transactions_by_version_txn_version.get import ApiForget


class TransactionsByVersionTxnVersion(
    ApiForget,
):
    pass
