from openapi_aptos_api.paths.blocks_block_height.get import ApiForget


class BlocksBlockHeight(
    ApiForget,
):
    pass
