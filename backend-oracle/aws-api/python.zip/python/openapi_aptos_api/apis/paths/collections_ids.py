from openapi_aptos_api.paths.collections_ids.get import ApiForget


class CollectionsIds(
    ApiForget,
):
    pass
