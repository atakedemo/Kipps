from openapi_aptos_api.paths.coins_latest.get import ApiForget


class CoinsLatest(
    ApiForget,
):
    pass
