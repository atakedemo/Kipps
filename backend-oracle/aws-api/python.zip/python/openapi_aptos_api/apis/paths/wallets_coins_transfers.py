from openapi_aptos_api.paths.wallets_coins_transfers.get import ApiForget


class WalletsCoinsTransfers(
    ApiForget,
):
    pass
