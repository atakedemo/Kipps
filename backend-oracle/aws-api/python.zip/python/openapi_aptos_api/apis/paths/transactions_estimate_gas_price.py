from openapi_aptos_api.paths.transactions_estimate_gas_price.get import ApiForget


class TransactionsEstimateGasPrice(
    ApiForget,
):
    pass
