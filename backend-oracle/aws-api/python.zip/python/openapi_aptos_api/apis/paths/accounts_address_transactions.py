from openapi_aptos_api.paths.accounts_address_transactions.get import ApiForget


class AccountsAddressTransactions(
    ApiForget,
):
    pass
