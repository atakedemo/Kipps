from openapi_aptos_api.paths.coins_transfers_coin_type.get import ApiForget


class CoinsTransfersCoinType(
    ApiForget,
):
    pass
