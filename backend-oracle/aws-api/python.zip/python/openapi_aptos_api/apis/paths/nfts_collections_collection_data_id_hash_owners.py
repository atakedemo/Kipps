from openapi_aptos_api.paths.nfts_collections_collection_data_id_hash_owners.get import ApiForget


class NftsCollectionsCollectionDataIdHashOwners(
    ApiForget,
):
    pass
