from openapi_aptos_api.paths.accounts_address_resources.get import ApiForget


class AccountsAddressResources(
    ApiForget,
):
    pass
