from openapi_aptos_api.paths.coins_transfers_blocks.get import ApiForget


class CoinsTransfersBlocks(
    ApiForget,
):
    pass
