from openapi_aptos_api.paths.coins.get import ApiForget


class Coins(
    ApiForget,
):
    pass
